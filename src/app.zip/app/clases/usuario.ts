export class Usuario {
    nombre:string; //defino la variable y el tipo

    constructor(){
        this.nombre = 'Maga';
    }
}
